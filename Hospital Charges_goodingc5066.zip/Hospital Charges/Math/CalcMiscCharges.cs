﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Math
{
    public class CalcMiscCharges
    {
        //Calculates total for usages of hospital equipment
        public static double MiscCharges(double MedicationCharges, double SurgicalCharges, double LabFees, double PhysicalFees)
        {
            double MiscChargess;

            MiscChargess = (MedicationCharges + SurgicalCharges+ LabFees + PhysicalFees);
            
            return MiscChargess;
        }
    }
}
