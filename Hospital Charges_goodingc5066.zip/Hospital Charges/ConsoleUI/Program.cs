﻿//Chrystian Gooding
//8/31/2020
//Hospital Charges
// This program ask user for their fees for hospital stay and returns their final charge
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            //Asks user how many days they were in the hospital
            StandardMessages.DaysinHospital();
            int DaysinHospital = Convert.ToInt32(Console.ReadLine());
            //Asks user how much they paid for medication
            StandardMessages.MedicationCharges();
            double MedicationCharges = Convert.ToDouble(Console.ReadLine());
            //Asks user how much they paid for surgery
            StandardMessages.SurgicalCharges();
            double SurgicalCharges = Convert.ToDouble(Console.ReadLine());
            //Asks user how much they paid for labs
            StandardMessages.LabeFees();
            double LabFees = Convert.ToDouble(Console.ReadLine());
            //Asks uer how much they paid for physical
            StandardMessages.PhysicalFees();
            double PhysicalFees = Convert.ToDouble(Console.ReadLine());
            //Displays total for  staying in the hospital
            Console.WriteLine("The daily total for staying in the hospital was:");
            Console.WriteLine(Math.CalcStayCharges.StayCharges(DaysinHospital));
            //Displays total for all uses of hospital equipment
            Console.WriteLine("The total for surgey, lab, medication and physical rehabilitation was:");
            Console.WriteLine(Math.CalcMiscCharges.MiscCharges(MedicationCharges, SurgicalCharges, LabFees, PhysicalFees));
            // Displays final total for hospital stay
            Console.WriteLine("The total price for the hospital stay was:");
            Console.WriteLine(Math.CalcTotalCharges.TotalCharges(DaysinHospital, MedicationCharges, SurgicalCharges, LabFees, PhysicalFees));
            Console.ReadLine();
        }
    }
}
