﻿//Chrystian Gooding
//9/21/2020
//Distance Calculator
//This program calculates distance based on speed and time given
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Display short message and ask user for speed  and converts input to int for calculation
            Console.WriteLine("Welcome to the Distance Calculator\nEnter the Speed of Travel:");
            int speed = Convert.ToInt32(Console.ReadLine());
            // ask user for time and converts to int for calculation
            Console.WriteLine("Enter the time:");
            int time = Convert.ToInt32(Console.ReadLine());
            //calculates distance traveled
            int distance = (speed * time);
            //displays calculation of distance for the user
            Console.WriteLine("_____________________________________________");
            Console.WriteLine($"The Distance traveled is: {distance} miles.");
            Console.ReadLine();
        }
    }
}
