﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area
{
    public class Calculations
    {
        // imports values for rectangle and calculates the area of the  rectangle and returns the area to the program to be displayed
        public static double areacalc(int Width, int Length)
        {
            int area = (Length * Width);

            return area;
        }

        public static double areacalc(double r, double p)
        {
            double area = (r * r * p);

            return area;

        }

        // imports values for cylinder and calculates the area of the  cylinder and returns the area to the program to be displayed
        public static double areacalc(double r, double h, double p)
        {
            double area = ((2 * p * r* r) + r * (2 * p * h));

            return area;
        }
    }
}
