﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class StandardMessages
    {
        public static void DisplayMenu()
        {

            Console.WriteLine("Please select from one of the options to calculate the Area. \n1.Circles\n2.Rectangles\n3.Cylinders\n4.Exit");
        }

        public static void UserChoice()
        {
            Console.WriteLine("Select an option");
        }

        public static void error()
        {
            Console.WriteLine("Please enter a valid option!!");
        }

        public static void exit()
        {
            Console.WriteLine("Thank you for using the Area Calculator!!");
        }

        public static void lines()
        {
            Console.WriteLine("___________________________");
        }
    }
}
