﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            double p = Math.PI;
            double r;
            double h;
            // do while statement to run code
            do
            {
                // displays menu
                StandardMessages.DisplayMenu();
                // asks and accepts user input
                StandardMessages.UserChoice();
                string input = Console.ReadLine();

                // if user enters 1 will take radius and calculate and display the circle's area
                if (input == "1")
                {
                    Console.WriteLine("Please enter the radius of the circle:");
                     r = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("The area of the Circle is:");
                    Console.WriteLine(Area.Calculations.areacalc(r, p));
                    StandardMessages.lines();
                }
                // if user enters 2 will take length and width of rectangle and calculate and display rectangle's area
                else if (input == "2")
                {
                    Console.WriteLine("Please enter the width of the rectangle:");
                    int Width = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Please enter the length of the rectangle:");
                    int Length = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("The area of the Rectangle is:");
                    Console.WriteLine(Area.Calculations.areacalc(Length, Width));
                    StandardMessages.lines();
                }
                // if user enters 3 will take radius and height of cylinder and calculate and display and cylinder's area 
                else if (input == "3")
                {
                    Console.WriteLine("Please enter the radius of the cylinder:");
                     r = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Please enter the height of the cylinder:");
                    h = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("The area of the Cylinder is:");
                    Console.WriteLine(Area.Calculations.areacalc(r, h, p));
                    StandardMessages.lines();
                }
                // if user enters 4 will exit the program and display exit message
                else if (input == "4")
                {
                    exit = true;
                    StandardMessages.exit();
                    Console.ReadLine();
                }
                // if user enters  anything but  1 to 4 will reprint menu and print error message
                else
                {
                    StandardMessages.error();
                    StandardMessages.lines();
                }
                //exits the program
            } while (exit == false);
        }
    }
}
