﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
   public static class StandardMessages
    {
        public static void DaysinHospital()
        {
            Console.WriteLine("How many days were spent in hospital:");
        }
        public static void MedicationCharges()
        {
            Console.WriteLine("What was the cost of the medicaton used:");
        }
        public static void SurgicalCharges()
        {
            Console.WriteLine("What was the cost of the surgery:");
        }
        public static void LabeFees()
        {
            Console.WriteLine("What was the cost of using the labs:");
        }
        public static void PhysicalFees()
        {
            Console.WriteLine("What was the cost of physical rehabilitation:");
        }
    }
}
