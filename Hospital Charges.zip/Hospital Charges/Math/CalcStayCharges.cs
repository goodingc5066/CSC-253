﻿using System;

namespace Math
{
    public class CalcStayCharges
    {
        //Calculates total for days stayed at hospital
        public static double StayCharges(int DaysinHospital)
        {
            int perDay = 350;

            double CostofDays;

            CostofDays = (DaysinHospital * perDay);

            return CostofDays;
        }
    }
}
