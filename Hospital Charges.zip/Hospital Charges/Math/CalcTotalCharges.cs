﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Math
{
    public class CalcTotalCharges
    {
        //Calculates Final total for hospital stay
        public static double TotalCharges(int DaysinHospital, double MedicationCharges, double SurgicalCharges, double LabFees, double PhysicalFees)
        {
                int perDay = 350;
                double CostofDays = (DaysinHospital * perDay);
                double MiscChargess;
                MiscChargess = (MedicationCharges + SurgicalCharges + LabFees + PhysicalFees);
                double TotalCharge = (CostofDays + MiscChargess);

            return TotalCharge;
        }
    }
}
