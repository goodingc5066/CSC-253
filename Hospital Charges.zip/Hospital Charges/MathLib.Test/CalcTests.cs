﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Math;
using Xunit;
namespace MathLib.Test
{
    public class CalcTests
    {
        [Fact]
        public void Misc_ShouldCalculateMiscCharges()
        {
            
            //Arrange
            double expected = 20;
            //Act
            double actual = CalcMiscCharges.MiscCharges(5, 5, 5, 5);
            //Assert
            Assert.Equal(expected, actual);
        }
        [Fact]
        public void Stay_ShouldCalculateStayCharges()
        {

            //Arrange
            double expected = 700;
            //Act
            double actual = CalcStayCharges.StayCharges(2);
            //Assert
            Assert.Equal(expected, actual);
        }
        [Fact]
        public void Total_ShouldCalculateTotalCharges()
        {

            //Arrange
            double expected = 720;
            //Act
            double actual = CalcTotalCharges.TotalCharges(2, 5, 5, 5,5);
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
