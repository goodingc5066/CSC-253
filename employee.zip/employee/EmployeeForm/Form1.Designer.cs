﻿namespace EmployeeForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBoxForEmployees = new System.Windows.Forms.GroupBox();
            this.submitEmployeeButton = new System.Windows.Forms.Button();
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeAgeLabel = new System.Windows.Forms.Label();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.employeeAgeTextBox = new System.Windows.Forms.TextBox();
            this.employeesNumberTextBox = new System.Windows.Forms.TextBox();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.listBoxforEmployees = new System.Windows.Forms.ListBox();
            this.groupBoxForEmployees.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxForEmployees
            // 
            this.groupBoxForEmployees.Controls.Add(this.submitEmployeeButton);
            this.groupBoxForEmployees.Controls.Add(this.employeeNameLabel);
            this.groupBoxForEmployees.Controls.Add(this.employeeAgeLabel);
            this.groupBoxForEmployees.Controls.Add(this.employeeNumberLabel);
            this.groupBoxForEmployees.Controls.Add(this.employeeAgeTextBox);
            this.groupBoxForEmployees.Controls.Add(this.employeesNumberTextBox);
            this.groupBoxForEmployees.Controls.Add(this.employeeNameTextBox);
            this.groupBoxForEmployees.Location = new System.Drawing.Point(12, 12);
            this.groupBoxForEmployees.Name = "groupBoxForEmployees";
            this.groupBoxForEmployees.Size = new System.Drawing.Size(776, 222);
            this.groupBoxForEmployees.TabIndex = 0;
            this.groupBoxForEmployees.TabStop = false;
            this.groupBoxForEmployees.Text = "Enter Employees Info:";
            // 
            // submitEmployeeButton
            // 
            this.submitEmployeeButton.Location = new System.Drawing.Point(347, 181);
            this.submitEmployeeButton.Name = "submitEmployeeButton";
            this.submitEmployeeButton.Size = new System.Drawing.Size(78, 26);
            this.submitEmployeeButton.TabIndex = 6;
            this.submitEmployeeButton.Text = "Submit";
            this.submitEmployeeButton.UseVisualStyleBackColor = true;
            this.submitEmployeeButton.Click += new System.EventHandler(this.submitEmployeeButton_Click);
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.AutoSize = true;
            this.employeeNameLabel.Location = new System.Drawing.Point(6, 64);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(122, 13);
            this.employeeNameLabel.TabIndex = 5;
            this.employeeNameLabel.Text = "Enter Employee\'s Name:";
            // 
            // employeeAgeLabel
            // 
            this.employeeAgeLabel.AutoSize = true;
            this.employeeAgeLabel.Location = new System.Drawing.Point(604, 64);
            this.employeeAgeLabel.Name = "employeeAgeLabel";
            this.employeeAgeLabel.Size = new System.Drawing.Size(113, 13);
            this.employeeAgeLabel.TabIndex = 4;
            this.employeeAgeLabel.Text = "Enter Employee\'s Age:";
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.AutoSize = true;
            this.employeeNumberLabel.Location = new System.Drawing.Point(303, 64);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(131, 13);
            this.employeeNumberLabel.TabIndex = 3;
            this.employeeNumberLabel.Text = "Enter Employee\'s Number:";
            // 
            // employeeAgeTextBox
            // 
            this.employeeAgeTextBox.Location = new System.Drawing.Point(607, 80);
            this.employeeAgeTextBox.Name = "employeeAgeTextBox";
            this.employeeAgeTextBox.Size = new System.Drawing.Size(163, 20);
            this.employeeAgeTextBox.TabIndex = 2;
            // 
            // employeesNumberTextBox
            // 
            this.employeesNumberTextBox.Location = new System.Drawing.Point(306, 80);
            this.employeesNumberTextBox.Name = "employeesNumberTextBox";
            this.employeesNumberTextBox.Size = new System.Drawing.Size(163, 20);
            this.employeesNumberTextBox.TabIndex = 1;
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(6, 80);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(163, 20);
            this.employeeNameTextBox.TabIndex = 0;
            // 
            // listBoxforEmployees
            // 
            this.listBoxforEmployees.FormattingEnabled = true;
            this.listBoxforEmployees.Location = new System.Drawing.Point(12, 249);
            this.listBoxforEmployees.Name = "listBoxforEmployees";
            this.listBoxforEmployees.Size = new System.Drawing.Size(776, 173);
            this.listBoxforEmployees.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxforEmployees);
            this.Controls.Add(this.groupBoxForEmployees);
            this.Name = "Form1";
            this.Text = "Employee Submission Form";
            this.groupBoxForEmployees.ResumeLayout(false);
            this.groupBoxForEmployees.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBoxForEmployees;
        private System.Windows.Forms.Button submitEmployeeButton;
        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeAgeLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.TextBox employeeAgeTextBox;
        private System.Windows.Forms.TextBox employeesNumberTextBox;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.ListBox listBoxforEmployees;
    }
}

