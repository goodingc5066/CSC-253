﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using employee;
using employeeLibrary;

namespace EmployeeForm
{
    public partial class Form1 : Form
    {
        // list to hold all created employees
        public List<Employee> employee = new List<Employee>();
        public Form1()
        {
            InitializeComponent();
           
        }



        private void submitEmployeeButton_Click(object sender, EventArgs e)
        {
            // clears employee listbox
            listBoxforEmployees.Items.Clear();
            //if statement that only accpets employee ages over 17
            if (int.Parse(employeeAgeTextBox.Text) > 16)  
            {
                //creates new employee from user input
                employee.Add(new Employee
                {
                    Name = employeeNameTextBox.Text,
                    PhoneNumber = employeesNumberTextBox.Text,
                    Age = int.Parse(employeeAgeTextBox.Text),


                });
            }
            else
            {
                MessageBox.Show("Error! Employee must be atleast 17 years old:");
            }
            //displays employee name in list box
            foreach (var item in employee)
            {
                listBoxforEmployees.Items.Add(item.Name);
            }
        }

     
    }
}
