﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employeeLibrary;

namespace employee
{
   public static class DisplayEmployees
    {//displays format for employee info
        public static void DisplayEmployeeInfo(List<Employee> inputList)
        {
            foreach (var employee in inputList)
            {
                Console.WriteLine($"Employee - {employee.Name}   Phone -{employee.PhoneNumber}   Age - {employee.Age}");
            }
        }
        // averages employees ages entered
        public static void DisplayAverageAge(List<Employee> inputList)
        {
            double age = 0;
            double average = 0.0;


            foreach (var employee in inputList)
            {
                age += employee.Age;
            }
            average = age / inputList.Count();
            Console.WriteLine(average);
        }
    }
}
