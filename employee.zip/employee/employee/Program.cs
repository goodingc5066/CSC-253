﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employeeLibrary;

/**
* 2/10/2020
* CSC 153
* Chrystian Gooding
* This program will ask the user for employee name, phone number and ages then will display this infor and average the age os the employees.
*/
namespace employee
{
    class Program
    {

        static void Main(string[] args)
        {

            // Create  sentry for loop
            
            bool exit = false;
            
          
            List<Employee> employees = new List<Employee>();
            do
            {
                // calling method to display menu
                Console.Write(employeeLibrary.StandardMessages.Menu());
                

                
                //Switch to direct to proper process
                switch (Console.ReadLine())
                {
                    case "1":
                        //Builds an employee from user info
                        BuildEmployee.BuildAEmployee(employees);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    case "2":
                        //Displays employee info
                        DisplayEmployees.DisplayEmployeeInfo(employees);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    case "3":
                        //Displays average age of employee
                        DisplayEmployees.DisplayAverageAge(employees);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    case "4":
                        exit = true;
                        //Exits program
                        Console.Write(StandardMessages.Exit());
                        Console.WriteLine(StandardMessages.CleaningCode());
                        Console.ReadLine();
                        break;
                    default:
                        //Displays choice error
                        Console.Write(StandardMessages.DisplayNumberError());
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                }
            } while (exit == false);
        }

       

        
    
    }
}
