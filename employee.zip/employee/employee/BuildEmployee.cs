﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employeeLibrary;

namespace employee
{
   public static class BuildEmployee
    {// puts user info entered into the list
        public static void BuildAEmployee(List<Employee> inputList)
        {
            bool correct = false;

            Employee output = new Employee();

            Console.WriteLine(StandardMessages.PromptForName());
            output.Name = Console.ReadLine();

            Console.WriteLine(StandardMessages.PromptForNumber());
            output.PhoneNumber = Console.ReadLine();

            do
            {
                Console.WriteLine(StandardMessages.PromptForAge());
                output.Age = TryParse.ParseToInt(Console.ReadLine());

                if (output.Age >= 16)
                {
                    correct = true;
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayAgeError());
                }

            } while (correct == false);

            inputList.Add(output);
        }
    }
}
