﻿//Chrystian Gooding
//9/9/2020
// Average Number of Letters
//This program lets user enter string and counts and displays the amount of words entered and averages the amount of letters per word.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        //This method calculates the amount of words in the string
        public static int InputWords(string input)
        {
            int wordcalc = input.Split(' ').Length;

            return wordcalc;
        }
        //This method calculates the average letters in the words inputted by the user
        public static int CountNonSpaceChars(string input, int words)
        {
            int result = 0;
            int average = 0;
            foreach (char c in input)
            {
                if (!char.IsWhiteSpace(c))
                {
                    result++;

                }
                average = (result / words);
            }
            return average;
        }

        static void Main(string[] args)
        {
            //asks user for input
            Console.WriteLine("Enter the sentence you would like counted:");
            //converts input to string
            string input = Convert.ToString(Console.ReadLine());
            //assigns method result to variables
            int words = InputWords(input);
            int letter = CountNonSpaceChars(input, words);
            //prints the resutls of the program
            Console.WriteLine("_____________________________________________");
            Console.WriteLine($"The amount of words are counted are: {words}");
            Console.WriteLine("_____________________________________________");
            Console.WriteLine($"The average number of letters is: {letter}");
            Console.ReadLine();
        }
    }
}
