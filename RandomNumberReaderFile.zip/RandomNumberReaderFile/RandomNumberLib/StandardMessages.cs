﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumberLib
{
    public static class StandardMessages
    {

        public static void Path()
        {
            Console.WriteLine("Enter the path for the file:");
        }
        public static void FileName()
        {
            Console.WriteLine("Enter the name of the file:");
        }
    }
}
