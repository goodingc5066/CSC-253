﻿//Chrystian Gooding
//10/4/2020
//RandomNumberFileReader
// This program reads from a file and counts the sum of the numbers and gives how many numbers were read.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            int count = 0;
            int total = 0;
            int numbers;

            //try catch to catch any errors
            try
            {
                //imports StreamReader
                StreamReader inputFile;
                //asks user for path to file
                RandomNumberLib.StandardMessages.Path();   
                string path = Console.ReadLine();
                //asks user for filename
                RandomNumberLib.StandardMessages.FileName();
                input = Console.ReadLine();
                //opens the file user path and filename entered
                inputFile = File.OpenText($@"{path}\{input}" + ".txt");
                //while loop that continues until line in file is blank
                while (!inputFile.EndOfStream)
                {
                    //imports variables as int and assign to numbers variable
                    numbers = int.Parse(inputFile.ReadLine());
                    //writes all the variables in numbers
                    Console.WriteLine(numbers);
                    // adds all the numbers together and assign result to total
                    total += numbers;
                    // counts all the numbers in the number
                    count++;

                   

                }
                //closes the file
                inputFile.Close();
                //prints the total sum of the variabales
                Console.WriteLine($"The numbers totaled is: {total}");
                //prints the total count of the variable
                Console.WriteLine($"The numbers counted from the file are: {count}");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
