﻿//Chrystian Gooding
//9/15/2020
//PigLatin
//This program will look at the sentence user has entered and return the sentence in piglatin.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static string ToPigLatin(string sentence)
        {
            //constant for vowels
            const string vowels = "AEIOUaeio";
            // list to hold userinput to convert to piglatin
            List<string> pigWords = new List<string>();
            // foreach loop to convert each word to piglatin
            foreach (string word in sentence.Split(' '))
            {
                string firstLetter = word.Substring(0, 1);
                string restOfWord = word.Substring(1, word.Length - 1);
                int currentLetter = vowels.IndexOf(firstLetter);

                if (currentLetter == -1)
                {
                    pigWords.Add(restOfWord + firstLetter + "AY");
                }
                else
                {
                    pigWords.Add(word + "AY");
                }
            }
            return string.Join(" ", pigWords);
        }


        static void Main(string[] args)
        {
           

            // asks user for sentence and converts it to string
            Console.WriteLine("Enter a sentence to convert to PigLatin:");
            Console.WriteLine("__________________________________");
            string str = Convert.ToString(Console.ReadLine());
            string pigLatin = ToPigLatin(str);
            // prints the sentence entered in piglatin
            Console.WriteLine(pigLatin);
            Console.ReadLine();
        }
    }
}
