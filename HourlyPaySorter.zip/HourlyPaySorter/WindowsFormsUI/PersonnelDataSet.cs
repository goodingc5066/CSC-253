﻿namespace WindowsFormsUI
{


    partial class PersonnelDataSet
    {
    }
}
