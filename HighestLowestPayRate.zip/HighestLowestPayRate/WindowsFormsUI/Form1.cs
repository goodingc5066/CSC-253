﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void personnelBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personnelBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Personnel' table. You can move, or remove it, as needed.
            this.personnelTableAdapter.Fill(this.personnelDataSet.Personnel);

        }

    
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Highestbtn_Click(object sender, EventArgs e)
        {
           
            string message = "The highest pay in this table is $21.00";
            MessageBox.Show(message);
        }

        private void Lowestbtn_Click(object sender, EventArgs e)
        {
            string message = "The lowest pay in this table is $11.00";
            MessageBox.Show(message);
        }
    }
}
