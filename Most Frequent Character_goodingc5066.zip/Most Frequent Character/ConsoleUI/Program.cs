﻿//Chrystian Gooding
//9/14/2020
//Most Frequent Character
//This program will look at the sentence user has entered and return the most seen character
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        public static char MostFrequentChar(string s)
        {
            int[] count = new int[256];
            // sets all char count at 0
            int max = 0;

            Char result = Char.MinValue;
            
            Array.Clear(count, 0, count.Length - 1);
            // foreach loop that  counts c once it is not a space
            foreach ( Char c in s)
            
                if(c !=' ' &&++count[c] > max)
                {
                    max = count[c];
                    result = c;
                    

                }
            // returns the most frequent character
             return result;
        }
        static void Main(string[] args)
        {
            // asks user for sentence and converts it to string
            Console.WriteLine("Please enter the sentence:");
            Console.WriteLine("__________________________________");
            string str = Convert.ToString(Console.ReadLine());
            // prints the most frequent character
            Console.WriteLine("The most repeated char is '{0}'", MostFrequentChar(str));
            Console.ReadLine();

        }
    }
}
