﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    //creates an onject for the class
    public static class Carbuild
    {
        public static Car BuildCar(Car inputCar)
        {
            StandardMessages.Year();
            inputCar.Year = Console.ReadLine();

            StandardMessages.Make();
            inputCar.Make = Console.ReadLine();

            return inputCar;

        }
    }
}
