﻿//Chrystian Gooding
//9/9/2020
// Word Counter
//This program lets user enter string and counts and displays the amount of words entered.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        //This method calculates the amount of words in the string
        public static int InputWords(string input)
        {
            int wordcalc = input.Split(' ').Length;

            return wordcalc;
        }
        static void Main(string[] args)
        {
            //asks user for input
            Console.WriteLine("Enter the sentence you would like counted:");
            //converts input to string
            string input = Convert.ToString(Console.ReadLine());
            //assigns method result to variables
            int words = InputWords(input);

            Console.WriteLine("_____________________________________________");
            Console.WriteLine($"The amount of words are counted are: {words}");
            Console.ReadLine();
        }
    }
}
