﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLib;
using Xunit;

namespace RetailLib.Test
{
    public class CalcTests
    {
        // test to test retail calculate method
        [Fact]
        public void CalculateRetailTest()
        {
            //Arrange
            double expected = 22;
            //Act
            double actual = Calculator.CalculateRetail(20, 10);
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
