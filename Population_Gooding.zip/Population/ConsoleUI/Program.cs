﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            //asks user to enter number of starting organisims
            Console.WriteLine("Starting number of organisims:");
            int Organisim = Convert.ToInt32(Console.ReadLine());
            //asks user to enter percent organisims increase by daily
            Console.WriteLine("Average daily increase in %:");
            int percent = Convert.ToInt32(Console.ReadLine());
            // ask users for days organisims are left to increase
            Console.WriteLine("Number of days to multiply:");
            int days = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("___________________________________");
            

            
            for (double i=1 ; i<=days ; i++)
            {
                

                double calculation = ((Organisim * percent * i )/ 100) ;

                calculation= (calculation + Organisim);

                Console.WriteLine($"The Organisim count  was {calculation} on day {i}");
             // print statement for results of the population growth
            }
            Console.ReadLine();
        }
    }
}
