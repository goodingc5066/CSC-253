﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Population_Math
{
    public class Calculations
    {      //imports the variables from start org and calculates the finalOrg
        public static int Population (int startOrg, int percent, int days)
        {
            int calculation;
            int finalOrg;
            calculation = ((startOrg * percent * days) / 100);
            finalOrg = (calculation + startOrg);

            return  finalOrg;
        }
    }
}
