﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceLib
{
    public class StandardMessages
    {

        public static void SpeedInput()
        {
            Console.WriteLine("Welcome to the Distance Calculator\nEnter the Speed of Travel:");
        }

        public static void TimeInput()
        {
            Console.WriteLine("Enter the time of travel:");
        }
        public static void EndMessage()
        {
            Console.WriteLine("Done!! Check Bin folder for results");
        }
    }
}
