﻿//Chrystian Gooding
//9/21/2020
//Distance File
//This program calculates distance based on speed and time given and returns the result in a txt file named Distance
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            //Display short message and ask user for speed  and converts input to int for calculation
            DistanceLib.StandardMessages.SpeedInput();
            int speed = Convert.ToInt32(Console.ReadLine());
            // ask user for time and converts to int for calculation
            DistanceLib.StandardMessages.TimeInput();
            int time = Convert.ToInt32(Console.ReadLine());
            //calculates distance traveled
            int distance = (speed * time);


            try
            {
                //outputs calculation to notepad named Distance.txt
                StreamWriter outputFile;


                outputFile = File.CreateText("Distance.txt");

                outputFile.WriteLine($"The Distance traveled is: {distance} miles.");


                outputFile.Close();

                DistanceLib.StandardMessages.EndMessage();
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
