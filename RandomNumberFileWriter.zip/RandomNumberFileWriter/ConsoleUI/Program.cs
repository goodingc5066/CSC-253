﻿//Chrystian Gooding
//9/28/2020
//RandomNumberFileWriter
// This program writes a user defined amount of numbers between 1 - 100 to a user defined named textfile.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {


            // imports random
            Random r = new Random();
            // ask user how many numbers they want to print out
            RandomNumberLib.StandardMessages.HowManyNumbers();
            int Numbers = Convert.ToInt32(Console.ReadLine());
            // ask user for the name of file they want the numbers printed to
            RandomNumberLib.StandardMessages.FileName();
            string fileName = Console.ReadLine();
            //creates a file with the name given by the user
            StreamWriter outputFile = File.CreateText($"{fileName}.txt");
            //try catch statement for streamwriter to catch any errors
            try
            {
                // for loop to print random numbers with the user specified limit
                for (int index = 0; index < Numbers; index++)
                {
                    outputFile.WriteLine(r.Next(1, 101));
                }
                outputFile.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }

            RandomNumberLib.StandardMessages.FinishMessage();
            Console.ReadLine();

        }
    }
}
