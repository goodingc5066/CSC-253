﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumberLib
{
    public static class StandardMessages
    {
        public static void HowManyNumbers()
        {
            Console.WriteLine("How Many Numbers between 1 - 100 do you want this program to produce:");
        }

        public static void FileName()
        {
            Console.WriteLine("What name do you want for the text file { Enter example: Number  (and it will be Number.txt)}: ");
        }

        public static void FinishMessage()
        {
            Console.WriteLine("File made check the Bin for your text file.");
        }
    }
}
